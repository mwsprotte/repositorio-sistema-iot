<?php
echo "<script> alert('Senha ou usuário incorretos!') </script>";
include 'index.php';
