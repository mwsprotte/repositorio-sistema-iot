<?php
include 'leitura.php';

if($_SERVER['REQUEST_METHOD'] == "POST")
{
	include 'excluir.php';
}
else 
{
	$limpar = '';
}

?>


<html>
<head>
	<title>Deformação de Rotores</title>

	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<link rel="icon" type="image/png" href="./assets/logo.png" />


	<!-- Import lib -->
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
	<link rel="stylesheet" type="text/css" href="./fontawesome-free/css/all.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	<!-- End import lib -->
	
	<link rel="stylesheet" type="text/css" href="./style.css">
</head>
<body class="overlay-scrollbar">
	<!-- navbar -->
	<div class="navbar">	
		<!-- nav left -->
		<ul class="navbar-nav">
			<li class="nav-item">
				<a class="nav-link">
					<i class="fas fa-bars" onclick="collapseSidebar()"></i>
				</a>
			</li>
			<li class="nav-item">
				<img src="assets/logo-dark.png" alt="Sensoria =ento logo" class="logo logo-light">
				<img src="assets/logo-light.png" alt="Sensoria =ento logo" class="logo logo-dark">
			</li>
		</ul>
		<!-- end nav left -->
		<!-- nav right -->
		<ul class="navbar-nav nav-right">

			<li class="nav-item mode">
				<a class="nav-link" href="#">
					<span>Deformação de Rotores | Última atualização: 
							<?php 
							echo $dataLeitura;
							?>
					</span>
				</a>
			</li>

			<li class="nav-item mode">
				<a class="nav-link" href="#" onclick="switchTheme()">
					<i class="fas fa-moon dark-icon"></i>
					<i class="fas fa-sun light-icon"></i>
				</a>
			</li>

			<li class="nav-item avt-wrapper">
				<div class="avt dropdown">
					<img src="assets/tuat.jpg" alt="fas fa-user-tie" class="dropdown-toggle" data-toggle="user-menu">
					<ul id="user-menu" class="dropdown-menu">
						<!-- <li class="dropdown-menu-item">
							<a class="dropdown-menu-link">
								<div>
									<i class="fas fa-user-tie"></i>
								</div>
								<span>Perfil</span>
							</a>
						</li> -->
						<!-- <li class="dropdown-menu-item">
							<a href="#" class="dropdown-menu-link">
								<div>
									<i class="fas fa-cog"></i>
								</div>
								<span>Configurações</span>
							</a>
						</li>
						<li class="dropdown-menu-item">
							<a href="#" class="dropdown-menu-link">
								<div>
									<i class="fas fa-chart-line"></i>
								</div>
								<span>Relatórios</span>
							</a>
						</li> -->
						<li class="dropdown-menu-item">
							<a href="acoes/logout.php" class="dropdown-menu-link">
								<div>
									<i class="fas fa-sign-out-alt"></i>
								</div>
								<span>Sair</span>
							</a>
						</li>
					</ul>
				</div>
			</li>
		</ul>
		<!-- end nav right -->
	</div>
	<!-- end navbar -->
	<!-- sidebar -->
	<div class="sidebar">
		<ul class="sidebar-nav">
			<li class="sidebar-nav-item">
				<a href="dashboard2.php" class="sidebar-nav-link ">
					<div>
						<i class="fas fa-tachometer-alt"></i>
					</div>
					<span>Dashboard</span>
				</a>
			</li>
			<li class="sidebar-nav-item">
				<a href="gerenciar.php" class="sidebar-nav-link active">
					<div>
						<i class="fas fa-tasks"></i>
					</div>
					<span>Gerenciar</span>
				</a>
			</li>
			<li class="sidebar-nav-item">
				<a href="relatorios.php" class="sidebar-nav-link">
					<div>
						<i class="fas fa-chart-line"></i>
					</div>
					<span>Relatórios</span>
				</a>
			</li>
			<li class="sidebar-nav-item">
				<a href="acoes/logout.php" class="sidebar-nav-link">
					<div>
						<i class="fas fa-sign-out-alt"></i>
					</div>
					<span>Sair</span>
				</a>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<!-- main content -->
	<div class="wrapper">
		<div class="row">
			
			<!-- <div class="col-3 col-m-6 col-sm-6">
				<div class="counter bg-success">
						<h3>
							
						</h3>
				</div>
			</div>
			 -->

			<div class="col-3 col-m-6 col-sm-6">
				<div class="counter bg-success">
					<form action="dashboard2.php" method="post">
						<label><h3>Filtrar resultado:</h3></label>
						<select name="escolha_sensor">
						<!-- isso serve só para indicar para a pessoa: -->
						<option value="Al" selected>Todos os sensores</option>
						<option value="01">Sensor 1</option>
						<option value="02">Sensor 2</option>
						</select>
						<input type="submit" name="escolher" value="Filtrar">
					</form>
				</div>
			</div>

			<div class="col-3 col-m-6 col-sm-6">
				<div class="counter bg-success">
					<form action="gerenciar.php" method="post">
					<label><h3>Limpar dados coletados em <?php echo $dataChart;?></h3>
					</label>
					<input type="submit" name="deletar" value="Limpar">
				</div>
			</div>

		</div>

		

	</div>
	<!-- end main content -->
	<!-- import script -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
	<script src="./script/index2.js"></script>
	<!-- end import script -->
</body>
</html>